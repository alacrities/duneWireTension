/*
 * Copyright (c) 2009-2013 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */



#include <stdio.h>
#include <string.h>

#include "xparameters.h"
#include "lwip/err.h"
#include "lwip/tcp.h"
#ifdef __arm__
#include "xil_printf.h"
#endif
#define XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR 0x44A50000
#define SEND_BUFSIZE (1024)
int transfer_mmUdpTx_data();
static int transferNumber = 1;

int transfer_data() {
  return 0;
}

void print_app_header() {
  xil_printf("\n\r\n\r-----lwIP TCP echo server ------\n\r");
  xil_printf("TCP packets sent to port 6001 will be echoed back\n\r");
}

err_t recv_callback(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err) {
  /* do not read the packet if we are not in ESTABLISHED state */
  if (!p) {
    tcp_close(tpcb);
    tcp_recv(tpcb, NULL );
    return ERR_OK;
  }

  /* indicate that the packet has been received */
  tcp_recved(tpcb, p->len);

  u32_t errCode = 0;

  int pktSN;
  int pktType;
  int pktAddr;
  int pktData;
  int cyLiteCmd;
  u16_t rxBufLength;
  u8_t cyLiteCmdType;
  xil_printf("--------------------------- \r\n");
  xil_printf("- TCP Packet received \r\n");
  xil_printf("- Transfer %d %s\r\n", transferNumber, " started.");
  rxBufLength = p->len;
  //process data start
  xil_printf("- # Words received: %d\r\n", (rxBufLength / 4 - 2));
  transferNumber++;
  unsigned int uiData;
  uiData = *(unsigned int *) (XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR + 4);
  xil_printf("Initial Status:  %x\n\r", uiData);
  xil_printf("--------------------------- \r\n");

  pktSN = ((*(u8_t*) (p->payload)) << 24)
    | ((*(u8_t*) (p->payload + 1)) << 16)
    | (*(u8_t*) (p->payload + 2)) << 8
    | (*(u8_t*) (p->payload + 3));

  pktType = ((*(u8_t*) (p->payload + 4)) << 24)
    | ((*(u8_t*) (p->payload + 5)) << 16)
    | (*(u8_t*) (p->payload + 6)) << 8
    | (*(u8_t*) (p->payload + 7));

  pktAddr = ((*(u8_t*) (p->payload + 8)) << 24)
    | ((*(u8_t*) (p->payload + 9)) << 16)
    | (*(u8_t*) (p->payload + 10)) << 8
    | (*(u8_t*) (p->payload + 11));

  //xil_printf("%10x %s\r\n",ipSel," ipSel.");

  xil_printf("%10x %s\r\n", pktSN, " pktSN.");
  xil_printf("%10x %s\r\n", pktType, " pktType.");
  xil_printf("%10x %s\r\n", pktAddr, " pktAddr");

  int regIndex;

  switch (pktType) {
  case 0xFE170000:
    xil_printf("Control word received \r\n");

    if (pktAddr == 0x00000000) {
      cyLiteCmdType = (*(u8_t*) (p->payload + 12));
      cyLiteCmd = ((*(u8_t*) (p->payload + 12)) << 24)
	| ((*(u8_t*) (p->payload + 13)) << 16)
	| (*(u8_t*) (p->payload + 14)) << 8
	| (*(u8_t*) (p->payload + 15));
      xil_printf("%10x %s\r\n", cyLiteCmdType, " cyLiteCmdType.");
      xil_printf("%10x %s\r\n", cyLiteCmd, " cyLiteCmd.");
      switch (cyLiteCmdType) {
      case 0x1:
	xil_printf("JDAQ FIFO command received \r\n");
	//mmtp	XIo_Out32(XPAR_CYLITE_MB_INTERFACE_1_BASEADDR + 0xC,  cyLiteCmd);
	break;
      case 0x2:
	xil_printf("\r\nrFIFO Packet Request \r\n");
	//mmtp	drain_cylite_rfifo();
	break;
      case 0x3:
	xil_printf("\r\nMM Data Packet Request \r\n");
	//mmtp	drain_cylite_mmData();
	break;
      case 0x4:
	xil_printf("\r\n Reset ON \r\n");
	for (regIndex = 0; regIndex < 256; regIndex++) {
	  uiData =
	    *(unsigned int *) (XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR
			       + (13 << 2));
	}//mmtp	XIo_Out32(XPAR_CYLITE_MB_INTERFACE_1_BASEADDR + 0xC,  0x10);
	//mmtp	close_Tcp();
	break;
      case 0x5:
	xil_printf("\r\n Reset OFF \r\n");
	//mmtp	XIo_Out32(XPAR_CYLITE_MB_INTERFACE_1_BASEADDR + 0xC,  0x00);
	break;
      default:
	xil_printf("unknown command \r\n\r\n");
	errCode = 2;
	break;
      }
    }
    xil_printf("end Control request! \r\n");
    break;

  case 0xFE170001:
    xil_printf("Read request \r\n");
    uiData = *(unsigned int *) (XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR
				+ (pktAddr << 2));
    xil_printf("Address:  %x", pktAddr);
    xil_printf(" Data:  %x\n\r", uiData);
    xil_printf("end Read request! \r\n");
    break;

  case 0xFE170002:
    xil_printf("start Write request! \r\n");
    int wIndex;
    for (wIndex = 0; wIndex < (rxBufLength / 4 - 3); wIndex++) {

    	pktData =
    			 ((*(u8_t*) (p->payload + 12 + (wIndex << 2))) << 24)
    			| ((*(u8_t*) (p->payload + 13 + (wIndex << 2))) << 16)
    			| (*(u8_t*) (p->payload + 14 + (wIndex << 2))) << 8
    			| (*(u8_t*) (p->payload + 15 + (wIndex << 2)));

    		      xil_printf("Address:  %x", pktAddr);
    		      xil_printf(" Data:  %x\n\r", pktData);

      *(unsigned int *) (XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR
			 + (pktAddr << 2)) = pktData;
    }
    xil_printf("end Write request! \r\n");
    break;

  case 0xFE170011:
    drainDebugFifo(pktAddr,tpcb);

    break;


  }
  uiData = *(unsigned int *) (XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR + 4);
  xil_printf("Resulting Status:  %x\n\r\n\r", uiData);

   /* echo back the payload */
  /* in this case, we assume that the payload is < TCP_SND_BUF */
  //original echo code
  /*  if (tcp_sndbuf(tpcb) > p->len) {
    err = tcp_write(tpcb, p->payload, p->len, 1);
  } else
  xil_printf("no space in tcp_sndbuf\n\r");*/

  /* free the received pbuf */
  pbuf_free(p);

  return ERR_OK;
}

err_t accept_callback(void *arg, struct tcp_pcb *newpcb, err_t err) {
  static int connection = 1;

  /* set the receive callback for this connection */
  tcp_recv(newpcb, recv_callback);

  /* just use an integer number indicating the connection id as the
     callback argument */
  tcp_arg(newpcb, (void*) connection);

  /* increment for subsequent accepted connections */
  connection++;

  return ERR_OK;
}

int start_application() {
  struct tcp_pcb *pcb;
  err_t err;
  unsigned port = 7;

  /* create new TCP PCB structure */
  pcb = tcp_new();
  if (!pcb) {
    xil_printf("Error creating PCB. Out of Memory\n\r");
    return -1;
  }

  /* bind to specified @port */
  err = tcp_bind(pcb, IP_ADDR_ANY, port);
  if (err != ERR_OK) {
    xil_printf("Unable to bind to port %d: err = %d\n\r", port, err);
    return -2;
  }

  /* we do not need any arguments to callback functions */
  tcp_arg(pcb, NULL );

  /* listen for connections */
  pcb = tcp_listen(pcb);
  if (!pcb) {
    xil_printf("Out of memory while tcp_listen\n\r");
    return -3;
  }

  /* specify callback to use for incoming connections */
  tcp_accept(pcb, accept_callback);

  xil_printf("TCP echo server started @ port %d\n\r", port);

  return 0;
}
int drainDebugFifo(int fifoAddr, struct tcp_pcb *tpcb) {
  int rDFifoTxbufLen = 256;
  u8_t rDFifoTxbuf[rDFifoTxbufLen];
  unsigned int statusFlags, rDFifoData;
  int i; 
  int statusBit;
  u8_t rfifoTxbuf[SEND_BUFSIZE];
  int rDFifoTxIndex = 4;
  int rfifo;
  u8_t fifoAddrB;

  u8_t *rDFifoB = (u8_t*) &rDFifoData;
  //  xil_printf("start drain fifo %x\r\n", fifoAddr);
  statusBit = fifoAddr & 0xF;
  //  xil_printf("start drain fifo %x\r\n", statusBit);
       rDFifoTxbuf[0] = 0xF0;
      rDFifoTxbuf[1] = 0x00;
      rDFifoTxbuf[2] = 0x00;
      rDFifoTxbuf[3] = 0x00;
  while (1) {
    statusFlags = *(unsigned int *) (XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR
				     + (0x0001 << 2));
    fifoAddrB = fifoAddr;
    statusBit = fifoAddr & 0xF;

   if ((statusFlags & 0x000001 << (statusBit*2)) == 0) 
      {

	rDFifoData = *(unsigned int *) (XPAR_AXI_LITE_PLI_0_S00_AXI_BASEADDR
				      + (fifoAddr << 2));

//		xil_printf("%x\n\r", rDFifoData);

	rDFifoTxbuf[rDFifoTxIndex] = rDFifoB[3];
	rDFifoTxIndex++;
	rDFifoTxbuf[rDFifoTxIndex] = rDFifoB[2];
	rDFifoTxIndex++;
	rDFifoTxbuf[rDFifoTxIndex] = rDFifoB[1];
	rDFifoTxIndex++;
	rDFifoTxbuf[rDFifoTxIndex] = rDFifoB[0];
	rDFifoTxIndex++;

	if (rDFifoTxIndex == rDFifoTxbufLen)
	  { 
	    transferTcpData(rDFifoTxbuf, &rDFifoTxIndex, tpcb);
	    rDFifoTxIndex = 0;

	  }
 

      } else {
     xil_printf("end drain fifo \r\n");
   
     transferTcpData(rDFifoTxbuf, &rDFifoTxIndex, tpcb);
     return 0;
   }
  }

}

int transferTcpData(u8_t *txBufData, int  *txBufLength, struct tcp_pcb *pcb)
{
  err_t err;
  
  err = tcp_write(pcb, txBufData, *txBufLength, 1);
  if (err != ERR_OK) {
    xil_printf("TransferTcpData Error on tcp_write: %d\r\n", err);
    return -1;
  }
  tcp_output(pcb);
    
  return 0;
}
